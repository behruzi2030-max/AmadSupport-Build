# -*- coding: utf-8 -*-
import os, sqlite3, hashlib, secrets
from datetime import datetime
from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.metrics import dp
from kivy.core.audio import SoundLoader

TITLE = "سامانه آماد و پشتیبانی\nپایگاه شهید صیاد شیرازی"

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    d = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 120000)
    return salt.hex()+":"+d.hex()

def verify_password(password, stored):
    try:
        s, d = stored.split(":")
        salt = bytes.fromhex(s)
        x = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 120000)
        return secrets.compare_digest(x.hex(), d)
    except Exception:
        return False

class DB:
    def __init__(self):
        self.path = os.path.join(App.get_running_app().user_data_dir, "amad_support.db")
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.init()

    def init(self):
        c = self.conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE,
          password_hash TEXT, first_name TEXT, last_name TEXT,
          role TEXT, active INTEGER DEFAULT 1)""")
        c.execute("""CREATE TABLE IF NOT EXISTS equipment(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, code TEXT,
          quantity INTEGER, status TEXT, created_at TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS warehouse(
          id INTEGER PRIMARY KEY AUTOINCREMENT, item_name TEXT, item_code TEXT,
          quantity INTEGER, location TEXT, created_at TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS transactions(
          id INTEGER PRIMARY KEY AUTOINCREMENT, equipment_name TEXT,
          receiver TEXT, action TEXT, created_at TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS repairs(
          id INTEGER PRIMARY KEY AUTOINCREMENT, equipment_name TEXT,
          issue TEXT, status TEXT, created_at TEXT, returned_at TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS noha(
          id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT UNIQUE,
          play_order INTEGER UNIQUE, active INTEGER DEFAULT 1)""")
        if c.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            c.execute("INSERT INTO users(username,password_hash,first_name,last_name,role) VALUES(?,?,?,?,?)",
                      ("hojjat behruzi",hash_password("H3521110801b"),"Hojjat","Behruzi","مدیریت سامانه"))
            c.execute("INSERT INTO users(username,password_hash,first_name,last_name,role) VALUES(?,?,?,?,?)",
                      ("mohamad raza zaree",hash_password("M3510706129z"),"Mohamad","Zaree","فرمانده عملیات"))
            c.execute("INSERT INTO users(username,password_hash,first_name,last_name,role) VALUES(?,?,?,?,?)",
                      ("user3",hash_password("U123456r"),"User","User","مسئول واحد"))
        self.conn.commit()

    def login(self,u,p):
        r=self.conn.execute("SELECT id,username,password_hash,first_name,last_name,role FROM users WHERE username=? AND active=1",(u,)).fetchone()
        return r if r and verify_password(p,r[2]) else None

    def count(self,t): return self.conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
    def add_equipment(self,*v): self.conn.execute("INSERT INTO equipment(name,code,quantity,status,created_at) VALUES(?,?,?,?,?)",(*v,now())); self.conn.commit()
    def add_warehouse(self,*v): self.conn.execute("INSERT INTO warehouse(item_name,item_code,quantity,location,created_at) VALUES(?,?,?,?,?)",(*v,now())); self.conn.commit()
    def add_transaction(self,*v): self.conn.execute("INSERT INTO transactions(equipment_name,receiver,action,created_at) VALUES(?,?,?,?)",(*v,now())); self.conn.commit()
    def add_repair(self,*v): self.conn.execute("INSERT INTO repairs(equipment_name,issue,status,created_at) VALUES(?,?,?,?)",(*v,now())); self.conn.commit()
    def reset_password(self,uid,p): self.conn.execute("UPDATE users SET password_hash=? WHERE id=?",(hash_password(p),uid)); self.conn.commit()

class Login(Screen):
    def __init__(self,**kw):
        super().__init__(**kw); b=BoxLayout(orientation="vertical",padding=dp(20),spacing=dp(10))
        b.add_widget(Label(text=TITLE,font_size=dp(25),halign="center"))
        b.add_widget(Label(text="نام کاربری (لاتین)")); self.u=TextInput(multiline=False); b.add_widget(self.u)
        b.add_widget(Label(text="رمز عبور")); self.p=TextInput(password=True,multiline=False); b.add_widget(self.p)
        x=Button(text="ورود",size_hint_y=None,height=dp(55)); x.bind(on_release=self.go); b.add_widget(x); self.add_widget(b)
    def go(self,*_):
        a=App.get_running_app(); r=a.db.login(self.u.text.strip(),self.p.text)
        if not r: a.alert("خطا","نام کاربری یا رمز عبور اشتباه است."); return
        a.user=r; a.root.current="home"; a.play_noha()

class Home(Screen):
    def __init__(self,**kw):
        super().__init__(**kw); self.build()
    def build(self):
        self.clear_widgets(); a=App.get_running_app(); r=a.user
        b=BoxLayout(orientation="vertical",padding=dp(10),spacing=dp(7))
        b.add_widget(Label(text=TITLE,font_size=dp(24),size_hint_y=None,height=dp(80)))
        self.clock=Label(font_size=dp(18),size_hint_y=None,height=dp(35)); b.add_widget(self.clock)
        b.add_widget(Label(text=f"کاربر: {r[1]} | سمت: {r[5]}",font_size=dp(17),size_hint_y=None,height=dp(40)))
        g=GridLayout(cols=2,spacing=dp(7))
        items=[
          ("داشبورد",lambda *_:a.alert("داشبورد",f"تجهیزات: {a.db.count('equipment')}\nانبار: {a.db.count('warehouse')}\nتحویل/عودت: {a.db.count('transactions')}\nتعمیرات: {a.db.count('repairs')}")),
          ("تجهیزات",lambda *_:a.form("تجهیزات",["نام تجهیز","کد تجهیز","تعداد","وضعیت"],a.db.add_equipment)),
          ("انبار",lambda *_:a.form("انبار",["نام کالا","کد کالا","تعداد","محل نگهداری"],a.db.add_warehouse)),
          ("تحویل و عودت",lambda *_:a.form("تحویل و عودت",["نام تجهیز","تحویل گیرنده","عملیات"],a.db.add_transaction)),
          ("تعمیرات",lambda *_:a.form("تعمیرات",["نام تجهیز","شرح ایراد","وضعیت"],a.db.add_repair)),
          ("گزارشات",lambda *_:a.alert("گزارشات",f"تاریخ و ساعت گزارش: {now()}\nخروجی Word/PDF در مرحله بعدی فعال می‌شود."))]
        if r[5]=="مدیریت سامانه":
            items += [("مدیریت کاربران",lambda *_:a.reset_user()),("مدیریت نوحه",lambda *_:a.alert("مدیریت نوحه","فقط مدیر سامانه دسترسی دارد؛ بارگذاری و ترتیب پخش در نسخه تکمیل‌شده فعال می‌شود."))]
        for t,cmd in items:
            q=Button(text=t,font_size=dp(18)); q.bind(on_release=cmd); g.add_widget(q)
        b.add_widget(g); self.add_widget(b); Clock.schedule_interval(self.tick,1)
    def tick(self,*_): self.clock.text=datetime.now().strftime("%Y-%m-%d   %H:%M:%S")

class Amad(App):
    def build(self):
        self.db=DB(); self.user=None; s=ScreenManager(); s.add_widget(Login(name="login")); s.add_widget(Home(name="home")); return s
    def alert(self,t,m): Popup(title=t,content=Label(text=m),size_hint=(.86,.45)).open()
    def form(self,title,labels,callback):
        box=BoxLayout(orientation="vertical",padding=dp(8),spacing=dp(5)); fs=[]
        for l in labels: box.add_widget(Label(text=l,size_hint_y=None,height=dp(25))); e=TextInput(multiline=False); fs.append(e); box.add_widget(e)
        bt=Button(text="ثبت",size_hint_y=None,height=dp(48)); box.add_widget(bt)
        pop=Popup(title=title,content=box,size_hint=(.92,.9))
        def submit(_):
            try:
                v=[x.text.strip() for x in fs]
                if "تعداد" in labels: v[labels.index("تعداد")]=int(v[labels.index("تعداد")])
                callback(*v); pop.dismiss(); self.alert("موفق","ثبت با تاریخ و ساعت دقیق انجام شد.")
            except Exception as e: self.alert("خطا",str(e))
        bt.bind(on_release=submit); pop.open()
    def reset_user(self):
        box=BoxLayout(orientation="vertical",padding=dp(8),spacing=dp(7)); uid=TextInput(hint_text="شناسه کاربر",multiline=False); pw=TextInput(hint_text="رمز جدید",password=True,multiline=False)
        box.add_widget(uid); box.add_widget(pw); bt=Button(text="تغییر / بازنشانی رمز",size_hint_y=None,height=dp(50)); box.add_widget(bt)
        pop=Popup(title="مدیریت کاربران",content=box,size_hint=(.9,.6))
        def go(_):
            try: self.db.reset_password(int(uid.text),pw.text); pop.dismiss(); self.alert("موفق","رمز با موفقیت بازنشانی شد.")
            except Exception as e: self.alert("خطا",str(e))
        bt.bind(on_release=go); pop.open()
    def play_noha(self):
        base=os.path.join(os.path.dirname(__file__),"assets","noha")
        try:
            fs=sorted([x for x in os.listdir(base) if x.lower().endswith((".mp3",".wav",".ogg"))])
            if fs:
                s=SoundLoader.load(os.path.join(base,fs[self.db.count("transactions")%len(fs)]))
                if s: s.play()
        except Exception: pass

if __name__=="__main__": Amad().run()

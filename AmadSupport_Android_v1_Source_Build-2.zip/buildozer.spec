[app]
title = Amad Support
package.name = amadsupport
package.domain = ir.sayyad.amadsupport
source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,atlas,json,mp3,wav,ogg
version = 0.1.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
